<?php 

	$data=$_GET['deleteid'];

	include 'connection.php';
	$sql="DELETE FROM tblreview WHERE fld_review_id='$data'";

	$query=mysqli_query($con,$sql);

	if ($query) {
		echo "<h1 class='text-success'>DATA DELETED SUCCESFULLY</h1>";
	}

	else{
		echo "<h1 class='text-danger'>DATA NOT DELETED</h1>";
	}

?>
<meta http-equiv="Refresh" content="1; url=food.php" />