<?php

include "connection.php";
session_start();
if($_POST)
{
	$con= mysqli_connect("localhost","root","","dbfood");
    if (!$con) {
      echo "<h1 class='text-warning' > Not-Connected </h1>";
    }
	$name=$_SESSION['admin'];
    $msg=$_POST['msg'];
    
	$sql="INSERT INTO `chat`(`name`, `message`) VALUES ('".$name."', '".$msg."')";

	$query = mysqli_query($con,$sql);
	if($query)
	{
		header('Location: dashboard.php');
	}
	else
	{
		echo "Something went wrong";
	}
	
	}
?>