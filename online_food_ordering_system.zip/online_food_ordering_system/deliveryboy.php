<?php
session_start();
include("connection.php");
extract($_REQUEST);
if(isset($_SESSION['id']))
{
 $id=$_SESSION['id'];
 $vq=mysqli_query($con,"select * from tbldeliveryboy where fld_username='$id'");
 $vr=mysqli_fetch_array($vq);
 $vrid=$vr['fld_del_id'];
}

if(!isset($_SESSION['id']))
{
	header("location:deliveryboy_login.php?msg=Please Login To continue");
}
else
{
$query=mysqli_query($con,"select * from tbldeliveryboy where fld_username='$id'");
if(mysqli_num_rows($query))
{   if(!file_exists("image/restaurant/".$id."/foodimages"))
	{
		$dir=mkdir("image/restaurant/".$id."/foodimages");
	}
	$row=mysqli_fetch_array($query);
    $v_id=$row['fld_del_id'];
}
else
{
	
	header("location:index.php");
	
	
}
}



if(isset($logout))
{
	session_destroy();
	header("location:index.php");
}
if(isset($upd_account))
				{
					
					//echo $fn;
					//echo $emm;
					//echo $add;
					if(mysqlI_query($con,"update tbldeliveryboy set fld_name='$fn',fld_username='$emm',fld_address='$add',fld_mob='$mob',fld_password='$pwsd' where fld_username='$id'"))
				   {
						 header("location:infoUpdate.php");
					}
			  }
			  if(isset($upd_logo))
			  {
				  if(isset($_SESSION['id']))
				  {
				  $log_img=mysqli_query($con,"select * from tbldeliveryboy where fld_username='$id'");
                  $log_img_row=mysqli_fetch_array($log_img);
				  $old_logo=$log_img_row['fld_db_img'];
				  $new_img_name=$_FILES['logo_pic']['name'];
				  
				  if(mysqli_query($con,"update tbldeliveryboy set fld_db_img='$new_img_name' where fld_username='$id'"))
				  {
					  unlink("image/restaurant/$id/$old_logo");
					  move_uploaded_file($_FILES['logo_pic']['tmp_name'],"image/restaurant/$id/".$_FILES['logo_pic']['name']);
				      
					  header("location:update_food.php");
					  
				  }
			  }
			  else
			  {
				  header("location:deliveryboy_login.php?msg=Please Login To continue");
			  }
			  }
			  
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
      <link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
     <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
	 <link rel="stylesheet" href="css/font.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
     <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
	 <style>
		ul li{}
		ul li a {color:white;padding:40px; }
		ul li a:hover {color:white;}
	 </style>
	 <style>
						h2{
						color:white;
						}
						label{
						color:white;
						}
						span{
							color:#673ab7;
							font-weight:bold;
						}
							.display-chat{
								height:300px;
								background-color:#d69de0;
								margin-bottom:4%;
								overflow:auto;
								padding:15px;
							}
							.message{
								background-color: #c616e469;
								color: white;
								border-radius: 5px;
								padding: 5px;
								margin-bottom: 3%;
							}
						</style>

</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
  
    <a class="navbar-brand" href="index.php"><span style="color:red;font-family: 'Permanent Marker', cursive;">Food Hunter</span></a>
    <?php
	if(!empty($id))
	{
	?>
	<a class="navbar-brand" style="color:black; text-decoration:none;" href="deliveryboy.php"><i class="far fa-user"><?php if(isset($id)) { echo $vr['fld_name']; }?></i></a>
	<?php
	}
	?>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
	
      <ul class="navbar-nav ml-auto">
        <li class="nav-item active">
          <a class="nav-link" href="index.php">Home
                
              </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="aboutus.php">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="services.php">Services</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="contact.php">Contact</a>
        </li>
		<li class="nav-item">
		  <form method="post">
          <?php
			if(empty($_SESSION['id']))
			{
			?>
		   <button class="btn btn-outline-danger my-2 my-sm-0" name="login">Log In</button>&nbsp;&nbsp;&nbsp;
            <?php
			}
			else
			{
			?>
			
			<button class="btn btn-outline-success my-2 my-sm-0" name="logout" type="submit">Log Out</button>&nbsp;&nbsp;&nbsp;
			<?php
			}
			?>
			</form>
        </li>
		
		
      </ul>
	  
    </div>
	
</nav>

<!--navbar ends-->


<br><br>
<div class="middle" style=" padding:40px; border:1px solid #ED2553;  width:100%;">
       <!--tab heading-->
	   <ul class="nav nav-tabs nabbar_inverse" id="myTab" style="background:#ED2553;border-radius:10px 10px 10px 10px;" role="tablist">
          
		  <li class="nav-item">
              <a class="nav-link" id="accountsettings-tab" data-toggle="tab" href="#accountsettings" role="tab" aria-controls="accountsettings" aria-selected="false">Account Settings</a>
          </li>
		  
		  <li class="nav-item">
              <a class="nav-link" id="logo-tab" data-toggle="tab" href="#logo" role="tab" aria-controls="logo" aria-selected="false">Update Image</a>
          </li>
		  <li class="nav-item">
              <a class="nav-link" id="status-tab" data-toggle="tab" href="#status" role="tab" aria-controls="status" aria-selected="false">Order Status</a>
          </li>
		  <li class="nav-item">
              <a class="nav-link" id="Managemsg-tab" data-toggle="tab" href="#Managemsg" role="tab" aria-controls="Managemsg" aria-selected="false">Chat</a>
          </li>
       </ul>
	   <br><br>
	   <span style="color:green;"><?php if(isset($msgs)) { echo $msgs; }?></span>

	   <div class="tab-content" id="myTabContent">
		
			 <!--tab 1-- starts-->
			 <div class="tab-pane fade" id="accountsettings" role="tabpanel" aria-labelledby="accountsettings-tab">
			    <form method="post" enctype="multipart/form-data">
				<?php
			    $upd_info=mysqli_query($con,"select * from tbldeliveryboy where fld_username='$id'");
				$upd_info_row=mysqlI_fetch_array($upd_info);
				 $nm=$upd_info_row['fld_name'];
				 $emm=$upd_info_row['fld_username'];
				 $log=$upd_info_row['fld_db_img'];
				$ad=$upd_info_row['fld_address'];
				$mb=$upd_info_row['fld_mob'];
				$psd=$upd_info_row['fld_password'];
				
				?>
				
                    <div class="form-group">
                      <label for="name">Name</label>
                      <input type="text" id="username" value="<?php if(isset($nm)){ echo $nm;}?>" class="form-control" name="fn" />
                    </div>
					<div class="form-group">
                      <label for="email">User Name</label>
                      <input type="text" id="email" value="<?php if(isset($emm)){ echo $emm;}?>" class="form-control" name="emm" readonly="readonly"/>
                    </div>
					<div class="form-group">
                      <label for="address">Address</label>
                      <input type="text" id="address" value="<?php if(isset($ad)){ echo $ad;}?>" class="form-control" name="add" required/>
                    </div>
					<div class="form-group">
                      <label for="mobile">Mobile</label>
                      <input type="text" id="mobile" pattern="^\d{10}$" value="<?php if(isset($mb)){ echo $mb;}?>" class="form-control" name="mob" required/>
                    </div>
					
                   <div class="form-group">
                      <label for="pwd">Password:</label>
                     <input type="password" name="pwsd" class="form-control" value="<?php if(isset($psd)){ echo $psd;}?>" id="pwd" required/>
                   </div>
				   
				   
 
                  <button type="submit" name="upd_account" style="background:#ED2553; border:1px solid #ED2553;" class="btn btn-primary">Update</button>
                  
			 </form>
			</div>
			<!--tab 2-- starts-->
			<div class="tab-pane fade" id="logo" role="tabpanel" aria-labelledby="logo-tab">
                <div class="container">
				    <form class="form" method="post" enctype="multipart/form-data">
				       <input type="file" name="logo_pic" accept="image/*" required/>
					   <button type="submit" name="upd_logo" class="btn btn-outline-primary">Update Image</button>
			        </form>
				</div>
			</div>
			<!--tab 3-- starts-->
			<div class="tab-pane fade " id="status" role="tabpanel" aria-labelledby="status-tab">
	            <table class="table">
					<tbody>
						<th>Order Id</th>
						<th>Customer Email</th>
						<th>Food Id</th>
						<th>Order Status</th>
						<th>Address</th>
						<th>Update Status</th>
						<?php
						$orderquery=mysqli_query($con,"select * from tblorder where fldstatus='In Process'");
						if(mysqli_num_rows($orderquery))
						{
							while($orderrow=mysqli_fetch_array($orderquery))
							{
								$stat=$orderrow['fldstatus'];
								?>
								<tr>
									<td><?php echo $orderrow['fld_order_id']; ?></td>
									<td><?php echo $orderrow['fld_email_id']; ?></td>
									<td><?php echo $orderrow['fld_food_id']; ?></td>
									<?php
										if($stat=="cancelled" || $stat=="Out Of Stock")
										{
											?>
												<td><i style="color:orange;" class="fas fa-exclamation-triangle"></i>&nbsp;<span style="color:red;"><?php echo $orderrow['fldstatus']; ?></span></td>
											<?php
										}
										else
										{
											?>
												<td><span style="color:green;"><?php echo $orderrow['fldstatus']; ?></span></td>
												
											<?php
										}
										?>
									<td><?php echo $orderrow['Address']; ?></td>
									<form method="post">
										<td><a href="changestatus.php?order_id=<?php echo $orderrow['fld_order_id']; ?>"><button type="button" name="changestatus">Update Status</button></a></td>
									</form>
								<tr>
								<?php
							}
						}
						?>
					</tbody>
				</table>
			 </div>

			 <!--tab 7-->
			<div class="tab-pane fade show" id="Managemsg" role="tabpanel" aria-labelledby="Managemsg-tab">
				<?php 
						$con= mysqli_connect("localhost","root","","dbfood");
						if (!$con) {
						echo "<h1 class='text-warning' > Not-Connected </h1>";
						}
						$sql="SELECT * FROM `chat`";
						$query = mysqli_query($con,$sql);
						?>
						

						<div class="container">
						
						<div class="display-chat">
						<?php
							if(mysqli_num_rows($query)>0)
							{
								while($row= mysqli_fetch_assoc($query))	
								{
						?>
								<div class="message">
									<p>
										<span><?php echo $row['name']; ?> :</span>
										<?php echo $row['message']; ?>
									</p>
								</div>
						<?php
								}
							}
							else
							{
						?>
						<div class="message">
									<p>
										No previous chat available.
									</p>
						</div>
						<?php
							} 
						?>

						</div>
						<form class="form-horizontal" method="post" action="sendMessageem.php">
							<div class="form-group">
							<div class="col-sm-10">          
								<textarea name="msg" class="form-control" placeholder="Type your message here..."></textarea>
							</div>
									
							<div class="col-sm-2">
								<button type="submit" style="background:#ED2553; border:1px solid #ED2553;" class="btn btn-primary">Send</button>
							</div>

							</div>
						</form>
						</div>
						
				</div>   	
			</div>
      
	</div>
	  </div>
	</div>  
	
</body>
</html>