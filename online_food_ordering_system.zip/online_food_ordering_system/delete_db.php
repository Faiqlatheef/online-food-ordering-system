
<?php 

	$data=$_GET['deleteid'];

	include 'connection.php';

	$sql="SELECT fld_username,fld_db_img FROM tbldeliveryboy WHERE fld_del_id='$data'";
	$query=mysqli_query($con,$sql);
	while ($row=mysqli_fetch_array($query)) {
		$img=$row['fld_username']."/" .$row['fld_db_img'];;
		unlink("image/restaurant/$img");
	}
	$sql="DELETE FROM tbldeliveryboy WHERE fld_del_id='$data'";

	$query=mysqli_query($con,$sql);

	if ($query) {
		echo "<h1 class='text-success display-1'>DATA DELETED SUCCESFULLY</h1>";
	}

	else{
		echo "<h1 class='text-danger display-1'>DATA NOT DELETED</h1>";
	}

?>

<meta http-equiv="Refresh" content="1; url=dashboard.php" />
